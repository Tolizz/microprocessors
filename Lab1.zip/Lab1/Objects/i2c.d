./objects/i2c.o: drivers\i2c.c drivers\platform.h \
  C:\Users\Apostolos\AppData\Local\Arm\Packs\Keil\STM32F4xx_DFP\2.17.1\Drivers\CMSIS\Device\ST\STM32F4xx\Include\STM32F4xx.h \
  C:\Users\Apostolos\AppData\Local\Arm\Packs\Keil\STM32F4xx_DFP\2.17.1\Drivers\CMSIS\Device\ST\STM32F4xx\Include\stm32f411xe.h \
  C:\Users\Apostolos\AppData\Local\Arm\Packs\ARM\CMSIS\6.3.0\CMSIS\Core\Include\core_cm4.h \
  C:\Users\Apostolos\AppData\Local\Arm\Packs\Keil\STM32F4xx_DFP\2.17.1\Drivers\CMSIS\Device\ST\STM32F4xx\Include\system_stm32f4xx.h \
  drivers\stm32f4xx_i2c.h drivers\STM32F4xx_RCC.h \
  drivers\STM32F4xx_GPIO.h
