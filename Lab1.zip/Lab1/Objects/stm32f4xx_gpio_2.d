./objects/stm32f4xx_gpio_2.o: drivers\stm32f4xx_gpio.c \
  drivers\stm32f4xx_rcc.h \
  C:\Users\Apostolos\AppData\Local\Arm\Packs\Keil\STM32F4xx_DFP\2.17.1\Drivers\CMSIS\Device\ST\STM32F4xx\Include\stm32f4xx.h \
  C:\Users\Apostolos\AppData\Local\Arm\Packs\Keil\STM32F4xx_DFP\2.17.1\Drivers\CMSIS\Device\ST\STM32F4xx\Include\stm32f411xe.h \
  C:\Users\Apostolos\AppData\Local\Arm\Packs\ARM\CMSIS\6.3.0\CMSIS\Core\Include\core_cm4.h \
  C:\Users\Apostolos\AppData\Local\Arm\Packs\Keil\STM32F4xx_DFP\2.17.1\Drivers\CMSIS\Device\ST\STM32F4xx\Include\system_stm32f4xx.h \
  drivers\stm32f4xx_gpio.h
